from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "paper-formal-writer" / "scripts"))
from artifact_checks import status_errors
from latex_integrity import POLICY_VERSION, evidence_snapshot


BASE_DIR = Path.cwd().resolve()
OUTPUT_DIR = BASE_DIR / "paper_output"
REPORT_JSON = OUTPUT_DIR / "qa" / "workflow_guard_report.json"
REPORT_MD = OUTPUT_DIR / "qa" / "workflow_guard_report.md"

BAD_RESULT_STATUSES = {
    "",
    "missing",
    "needs_real_modeling",
    "draft_contract",
    "to_be_filled",
    "template",
    "draft",
    "scaffold_result_needs_review",
}

STEP_ORDER = ["S0", "S1", "S2", "S3", "S4", "S5", "S6", "S7", "S8"]


def configure_utf8_stdio() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass


def rel(path: Path) -> str:
    try:
        return path.resolve().relative_to(BASE_DIR).as_posix()
    except Exception:
        return str(path).replace("\\", "/")


def load_json(path: Path) -> Any:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"__error__": f"{type(exc).__name__}: {exc}"}


def status_of(item: Any) -> str:
    if not isinstance(item, dict):
        return ""
    return str(item.get("status") or item.get("evidence_status") or "").strip()


def check_json_file(path: Path, failures: list[str]) -> Any:
    data = load_json(path)
    if data is None:
        failures.append(f"缺少文件：{rel(path)}")
        return None
    if isinstance(data, dict) and data.get("__error__"):
        failures.append(f"JSON 无法读取：{rel(path)} ({data['__error__']})")
        return None
    return data


def check_text_file(path: Path, failures: list[str]) -> None:
    if not path.exists():
        failures.append(f"缺少文件：{rel(path)}")
    elif path.is_file() and path.stat().st_size == 0:
        failures.append(f"文件为空：{rel(path)}")


def question_ids(model_route: Any) -> list[str]:
    questions = model_route.get("questions") if isinstance(model_route, dict) else []
    result: list[str] = []
    if isinstance(questions, list):
        for item in questions:
            if isinstance(item, dict):
                qid = str(item.get("question_id") or item.get("id") or "").strip()
                if qid:
                    result.append(qid)
    return sorted(set(result))


def check_s0() -> dict[str, Any]:
    failures: list[str] = []
    report = check_json_file(OUTPUT_DIR / "preflight_report.json", failures)
    if isinstance(report, dict) and str(report.get("status") or "").upper() != "PASS":
        failures.append("preflight_report.json status 不是 PASS。")
    return {"step": "S0", "name": "准入预检", "status": "PASS" if not failures else "FAIL", "failures": failures}


def check_s1() -> dict[str, Any]:
    failures: list[str] = []
    check_json_file(OUTPUT_DIR / "step1" / "problem_analysis.json", failures)
    return {"step": "S1", "name": "审题分析", "status": "PASS" if not failures else "FAIL", "failures": failures}


def check_s2() -> dict[str, Any]:
    failures: list[str] = []
    model_route = check_json_file(OUTPUT_DIR / "plan" / "model_route.json", failures)
    check_json_file(OUTPUT_DIR / "plan" / "rubric_alignment.json", failures)
    check_text_file(OUTPUT_DIR / "plan" / "scoring_strategy.md", failures)
    if isinstance(model_route, dict) and not question_ids(model_route):
        failures.append("model_route.json 中没有 question_id/id，无法追踪子问题。")
    return {"step": "S2", "name": "模型路线", "status": "PASS" if not failures else "FAIL", "failures": failures}


def check_s3() -> dict[str, Any]:
    failures: list[str] = []
    check_json_file(OUTPUT_DIR / "plan" / "data_plan.json", failures)
    check_json_file(OUTPUT_DIR / "plan" / "visualization_plan.json", failures)
    check_json_file(OUTPUT_DIR / "figure_index.json", failures)
    load_report = check_json_file(OUTPUT_DIR / "data_cleaned" / "load_report.json", failures)
    if isinstance(load_report, dict) and str(load_report.get("status") or "").upper() == "FAIL":
        failures.append("data_cleaned/load_report.json status 为 FAIL。")
    return {"step": "S3", "name": "数据与图表计划", "status": "PASS" if not failures else "FAIL", "failures": failures}


def check_s4() -> dict[str, Any]:
    failures: list[str] = []
    modeling_dir = OUTPUT_DIR / "code" / "modeling"
    if not modeling_dir.exists():
        failures.append(f"缺少建模代码目录：{rel(modeling_dir)}")
    else:
        scripts = sorted(modeling_dir.glob("q*_model.py"))
        if not scripts:
            failures.append("paper_output/code/modeling/ 中没有 q*_model.py。")
        if not (modeling_dir / "run_modeling.py").exists():
            failures.append("缺少 paper_output/code/modeling/run_modeling.py。")
    return {"step": "S4", "name": "建模代码", "status": "PASS" if not failures else "FAIL", "failures": failures}


def _items(data: Any, key: str) -> list[dict[str, Any]]:
    if not isinstance(data, dict) or not isinstance(data.get(key), list):
        return []
    return [item for item in data[key] if isinstance(item, dict)]


def check_s5() -> dict[str, Any]:
    failures: list[str] = []
    model_results = check_json_file(OUTPUT_DIR / "results" / "model_results.json", failures)
    metrics = check_json_file(OUTPUT_DIR / "results" / "metrics.json", failures)
    conclusions = check_json_file(OUTPUT_DIR / "results" / "conclusions.json", failures)
    table_index = check_json_file(OUTPUT_DIR / "tables" / "table_index.json", failures)

    for item in _items(model_results, "questions"):
        qid = str(item.get("question_id") or "UNKNOWN")
        state = status_of(item)
        if status_errors(item, qid, required=True):
            failures.append(f"{qid}: model_results 状态仍不是正式结果：{state or 'missing'}")
        provenance = item.get("execution_provenance")
        if not isinstance(provenance, dict):
            failures.append(f"{qid}: 缺少 execution_provenance，无法证明结果来自实际代码运行。")
        elif provenance.get("run_exit_code") not in (0, "0"):
            failures.append(f"{qid}: execution_provenance.run_exit_code 不是 0。")

    for label, data, key in (
        ("metrics", metrics, "items"),
        ("conclusions", conclusions, "items"),
        ("table_index", table_index, "tables"),
    ):
        if data is not None and not _items(data, key):
            failures.append(f"{label} 中没有可追踪条目。")
        for item in _items(data, key):
            state = status_of(item)
            if status_errors(item, label, required=True):
                failures.append(f"{label}: 条目仍是草稿/待补状态：{state or 'missing'}")
    return {"step": "S5", "name": "结果证据", "status": "PASS" if not failures else "FAIL", "failures": failures}


def check_s6() -> dict[str, Any]:
    failures: list[str] = []
    gate = check_json_file(OUTPUT_DIR / "qa" / "evidence_gate_report.json", failures)
    if isinstance(gate, dict) and str(gate.get("status") or "").upper() != "PASS":
        failures.append("evidence_gate_report.json status 不是 PASS。")
    if isinstance(gate, dict):
        if type(gate.get("policy_version")) is not int or gate["policy_version"] != POLICY_VERSION:
            failures.append("Legacy evidence policy; rerun evidence_gate.py.")
        try:
            if not gate.get("input_hashes") or gate["input_hashes"] != evidence_snapshot(BASE_DIR):
                failures.append("Evidence inventory changed; rerun evidence_gate.py.")
        except (ValueError, OSError) as exc:
            failures.append(str(exc))
    return {"step": "S6", "name": "证据门禁", "status": "PASS" if not failures else "FAIL", "failures": failures}


def check_s7() -> dict[str, Any]:
    failures: list[str] = []
    check_json_file(OUTPUT_DIR / "plan" / "paper_outline.json", failures)
    check_text_file(OUTPUT_DIR / "final_paper_source.md", failures)
    check_text_file(OUTPUT_DIR / "final_paper.docx", failures)
    return {"step": "S7", "name": "正式稿", "status": "PASS" if not failures else "FAIL", "failures": failures}


def check_s8() -> dict[str, Any]:
    failures: list[str] = []
    report = check_json_file(OUTPUT_DIR / "format_check_report.json", failures)
    if isinstance(report, dict) and str(report.get("status") or "").upper() != "PASS":
        failures.append("format_check_report.json status 不是 PASS。")
    return {"step": "S8", "name": "格式门禁", "status": "PASS" if not failures else "FAIL", "failures": failures}


CHECKERS = {
    "S0": check_s0,
    "S1": check_s1,
    "S2": check_s2,
    "S3": check_s3,
    "S4": check_s4,
    "S5": check_s5,
    "S6": check_s6,
    "S7": check_s7,
    "S8": check_s8,
}


def evaluate(target_step: str) -> dict[str, Any]:
    target_index = STEP_ORDER.index(target_step)
    checked_steps = STEP_ORDER[: target_index + 1]
    step_reports = [CHECKERS[step]() for step in checked_steps]
    failures = [f"{item['step']}: {failure}" for item in step_reports for failure in item["failures"]]
    return {
        "schema_version": "1.0",
        "generated_by": "paper-workflow-orchestrator/scripts/workflow_guard.py",
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "target_step": target_step,
        "status": "PASS" if not failures else "FAIL",
        "steps": step_reports,
        "failures": failures,
    }


def write_reports(report: dict[str, Any]) -> None:
    REPORT_JSON.parent.mkdir(parents=True, exist_ok=True)
    REPORT_JSON.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = [
        "# Workflow Guard Report",
        "",
        f"- Target step: `{report['target_step']}`",
        f"- Status: `{report['status']}`",
        f"- Generated at: `{report['generated_at']}`",
        "",
        "## Steps",
    ]
    for item in report["steps"]:
        lines.append(f"- {item['step']} {item['name']}: `{item['status']}`")
        for failure in item["failures"]:
            lines.append(f"  - {failure}")
    REPORT_MD.write_text("\n".join(lines).strip() + "\n", encoding="utf-8")


def main() -> int:
    configure_utf8_stdio()
    parser = argparse.ArgumentParser(description="Check MathModel S0-S8 workflow state.")
    parser.add_argument("--step", choices=STEP_ORDER, required=True, help="Check all workflow requirements up to this step.")
    args = parser.parse_args()
    report = evaluate(args.step)
    write_reports(report)
    print(f"workflow guard report: {rel(REPORT_JSON)}")
    if report["status"] == "PASS":
        print(f"[WORKFLOW PASS] {args.step}")
        return 0
    print(f"[WORKFLOW FAIL] {args.step}")
    for failure in report["failures"][:12]:
        print(f" - {failure}")
    if len(report["failures"]) > 12:
        print(f" - ...{len(report['failures']) - 12} more failures in report.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
