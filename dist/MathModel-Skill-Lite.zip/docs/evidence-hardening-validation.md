# Evidence Hardening Validation

Date: 2026-10-19
Edition: lite
Version: 2.2.1-lite.6
Local environment: Windows, Python 3.11.1.

## Scope

Backport evidence-status and artifact-integrity safeguards without merging editions or changing their installation architecture. The Standard branch and existing competition examples were not modified.

## Results

15 legacy cases passed; fresh-output suite: 14 passed, 2 skipped (16 total).

- Canonical payloads synchronized to the edition's supported platforms.
- Skill Creator validation passed for all SKILL.md entries.
- Archives rebuilt from canonical sources; tracked archive contents and repeat-build consistency checked locally.
- GitHub's other operating systems and Python 3.12 are not local test results.
- Two symlink tests skipped because this Windows host cannot create the links. Existing CI runs these tests where supported.

## Regression Coverage

- Explicit failed, unknown, empty or contradictory statuses cannot be hidden by a positive enclosing status.
- Raster images are actually decoded; generated CSV/TSV/XLSX data tables are parsed.
- Fresh hashes do not make corrupted content acceptable.
- Final reports include actual input/output hashes. Raw source files remain unchanged; output-table encoding requirements are not imposed on raw inputs.
- Existing result documents without per-question status remain compatible; explicitly declared states are checked.

## Commands

```text
python tests/run_lite_tests.py
python tests/test_fresh_outputs.py
python scripts/check_skills.py
python scripts/build_release_packages.py --verify
```

## Limits

Lite remains a six-step basic-report workflow. No OMML or PDF acceptance is added.
File hashes record integrity, not an adversarial sandbox or proof of scientific correctness. Reviewing the original problem, checking units and interpretation, and testing real contest cases remain necessary.
No tags or releases were created for this update.
